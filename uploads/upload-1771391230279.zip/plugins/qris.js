/*
hapus aja di atas ini 

import { Markup } from 'telegraf'

// ==========================================
// 🔧 LOGIC TOPUP
// Config API ada di config.js (global.paymentConfig)
// ==========================================

export default {
  cmd: ['deposit', 'depo', 'topup', 'isi'],
  desc: 'Top Up Saldo Otomatis (via QRIS)',
  owner: false,
  
  async run(bot, ctx, db) {
     const args = ctx.message.text.split(' ')
     const amount = parseInt(args[1])
     
     // 1. Validasi Input
     if (!amount || isNaN(amount)) {
         await ctx.reply(`
💰 *FORMAT DEPOSIT SALDO*
Gunakan command:
\`/deposit <jumlah>\`

Contoh:
\`/deposit 10000\` (Isi 10rb)
\`/deposit 50000\` (Isi 50rb)

_Minimal deposit: Rp 1.000_
`, { parse_mode: 'Markdown' })
         return
     }

     if (amount < 1000) {
         await ctx.reply('❌ Minimal deposit Rp 1.000 bro!')
         return
     }

     // 2. Proses Pembuatan Payment (Simulasi)
     const processingMsg = await ctx.reply('🔄 _Sedang membuat tagihan QRIS..._', { parse_mode: 'Markdown' })
     
     try {
         // >>> PANGGIL FUNGSI CREATE PAYMENT DI SINI <<<
         const payment = await createPayment(amount, ctx.from)
         
         // SIMPAN TRANSAKSI KE DB
         await db.addTransaction(payment.refId, ctx.from.id, amount, payment)
         
         // 3. Tampilkan Invoice ke User
         const caption = `*📫 INVOICE DEPOSIT*

🆔 Ref ID: \`${payment.refId}\`
💰 Nominal: *Rp ${amount.toLocaleString('id-ID')}*
📅 Tanggal: ${new Date().toLocaleString('id-ID')}

_Silakan scan QRIS di atas sebelum waktu habis!_
_Saldo akan masuk otomatis setelah pembayaran berhasil._`
         
         const keyboard = Markup.inlineKeyboard([
             [Markup.button.callback('🔄 Cek Status', `checkstatus_${payment.refId}`)],
             [Markup.button.callback('❌ Batalkan', `cancel_deposit_${payment.refId}`)],
             [Markup.button.callback('📞 Bantuan', 'contact_owner')]
         ])

         // Kirim QR Code (Disini pakai dummy QR API google chart sbg contoh)
         // Nanti diganti payment.qr_url dari API beneran
         await ctx.replyWithPhoto(payment.qrUrl, {
             caption: caption,
             parse_mode: 'Markdown',
             ...keyboard
         })
         
         // Hapus pesan loading
         await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id)

     } catch (err) {
         console.error('Deposit Error:', err)
         await ctx.reply('❌ Gagal membuat pembayaran. Coba lagi nanti atau hubungi Admin.')
     }
  }
}

// ==========================================
// 🔌 BAGIAN INTEGRASI API (MODIF DI SINI)
// ==========================================

async function createPayment(amount, user) {
    // [TODO] 1. Ganti logic ini dengan fetch ke API Provider
    // Contoh logic simulasi:
    
    // const response = await fetch(global.paymentConfig.createUrl, { ... })
    // const data = await response.json()
    
    // MOCK DATA (Pura-pura sukses)
    const refId = 'TRX-' + Date.now()
    // QR Code Generator (Dummy) - Ganti dengan payment_url dari API
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=MOCK_PAYMENT_${refId}_${amount}`
    
    return {
        refId: refId,
        amount: amount,
        qrUrl: qrUrl,
        status: 'pending'
    }
}

// Callback untuk Cek Status Manual
export async function checkPaymentStatus(ctx, db, refId) {
    // [TODO] 2. Logic Cek Status ke API Provider
    // const status = await fetch(...)
    
    // MOCK RESPONS (Selalu pending di demo ini, ganti logicnya nanti)
    const isPaid = false // Ubah true jika sudah bayar
    
    if (isPaid) {
        // Tambah saldo user
        // await db.addSaldo(userId, amount)
        await ctx.answerCbQuery('✅ Pembayaran Berhasil! Saldo ditambahkan.', { show_alert: true })
    } else {
        await ctx.answerCbQuery('⏳ Menunggu Pembayaran...', { show_alert: true })
        // await ctx.reply('Belum ada pembayaran masuk. Coba lagi 1 menit.')
    }
}


hapus aja di bawah ini 
*/ 