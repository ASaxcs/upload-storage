export default {
  cmd: ['cekid', 'id', 'getid'],
  desc: 'Cek ID User & Group/Channel',
  owner: false,
  
  async run(bot, ctx, db) {
    const chat = ctx.chat
    const user = ctx.from
    const message = ctx.message

    let msg = `*🆔 INFO ID DETECTED*\n`
    
    // User Info
    msg += `\n👤 *USER INFO*`
    msg += `\n• Name: ${user.first_name} ${user.last_name || ''}`
    msg += `\n• Username: @${user.username || '-'}`
    msg += `\n• ID: \`${user.id}\``
    
    // Chat Info (Group/Channel)
    msg += `\n\n💬 *CHAT INFO*`
    msg += `\n• Title: ${chat.title || 'Private Chat'}`
    msg += `\n• Type: ${chat.type}`
    msg += `\n• ID: \`${chat.id}\``

    // Reply to message info (if any)
    if (message.reply_to_message) {
        const reply = message.reply_to_message
        const replyUser = reply.from
        const replyChat = reply.chat

        msg += `\n\n↩️ *REPLY INFO*`
        if (replyUser) {
             msg += `\n• From Name: ${replyUser.first_name}`
             msg += `\n• From ID: \`${replyUser.id}\``
        }
        if (reply.forward_from_chat) {
             msg += `\n• Fwd From Channel: ${reply.forward_from_chat.title}`
             msg += `\n• Fwd Channel ID: \`${reply.forward_from_chat.id}\``
        }
    }

    await ctx.reply(msg, { parse_mode: 'Markdown' })
  }
}
