export default {
  cmd: ['request', 'req'],
  desc: 'Kirim request/saran ke Owner',
  owner: false,
  
  async run(bot, ctx, db) {
    const args = ctx.message.text.split(' ')
    const requestText = args.slice(1).join(' ')
    
    // Validasi input
    if (!requestText) {
      await ctx.reply(`
╭━━━━━━━━━━━━━━━━━━╮
│  📨 *KIRIM REQUEST*
╰━━━━━━━━━━━━━━━━━━╯

Gunakan command ini untuk mengirim saran, request fitur, atau lapor bug langsung ke Owner (Privat).

Cara pakai:
\`/request <pesan anda>\`

Contoh:
\`/request Min, tolong adain pembayaran via QRIS dong!\`
`.trim(), { parse_mode: 'Markdown' })
      return
    }

    // Cek ID Group Owner
    console.log('[DEBUG REQUEST] Owner Group ID:', global.ownerGroupId)
    if (!global.ownerGroupId) {
       await ctx.reply('❌ Sistem Request sedang maintenance (Owner Group not set).')
       return
    }

    // Kirim ke Group Owner
    try {
        const notif = `📨 *REQUEST USER BARU*\n\n👤 Dari: @${ctx.from.username || 'User'} (\`${ctx.from.id}\`)\n💬 Pesan:\n"${requestText}"`
        
        await bot.telegram.sendMessage(global.ownerGroupId, notif, { parse_mode: 'Markdown' })
        
        // Reply User
        await ctx.reply(`✅ *Pesan Terkirim!*\nRequest Anda telah diteruskan ke Owner. Terima kasih atas masukannya! 🙏`, { parse_mode: 'Markdown' })
        
    } catch (err) {
        console.error('Gagal kirim request:', err)
        await ctx.reply('⚠️ Gagal mengirim pesan. Silakan coba lagi nanti.')
    }
  }
}
