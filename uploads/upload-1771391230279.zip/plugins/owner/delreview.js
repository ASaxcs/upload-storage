export default {
  cmd: ['delreview', 'hapusulasan'],
  desc: 'Hapus ulasan user (Admin Only)',
  owner: true,
  
  async run(bot, ctx, db) {
    const args = ctx.message.text.split(' ')
    const indexStr = args[1]
    
    // 1. Tampilkan List jika tidak ada argumen
    if (!indexStr) {
        const reviews = db.getReviews(50) // Ambil banyak untuk admin
        
        if (reviews.length === 0) {
            await ctx.reply('❌ Tidak ada ulasan untuk dihapus.')
            return
        }

        let msg = `*🗑️ LIST ULASAN (HAPUS)*\n\n`
        reviews.forEach((r, i) => {
             const date = new Date(r.date).toLocaleDateString('id-ID')
             // Potong teks panjang
             const safeText = r.text.length > 20 ? r.text.substring(0, 20) + '...' : r.text
             msg += `*${i+1}.* ${r.username}: "${safeText}"\n`
        })
        
        msg += `\n_Cara hapus: /delreview <nomor>_\nContoh: \`/delreview 1\``
        await ctx.reply(msg, { parse_mode: 'Markdown' })
        return
    }

    // 2. Hapus berdasarkan indeks
    const index = parseInt(indexStr) - 1 // Convert 1-based to 0-based
    
    if (isNaN(index)) {
        await ctx.reply('❌ Masukkan nomor yang valid!')
        return
    }

    const deleted = await db.deleteReview(index)
    
    if (deleted) {
        await ctx.reply(`✅ Ulasan dari *${deleted.username}* berhasil dihapus!`, { parse_mode: 'Markdown' })
    } else {
        await ctx.reply('❌ Gagal menghapus. Nomor tidak ditemukan.')
    }
  }
}
