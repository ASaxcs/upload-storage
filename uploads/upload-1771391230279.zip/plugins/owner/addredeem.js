import { formatRupiah, generateRedeemCode, formatExpiry } from '../../lib/helpers.js'

export default {
  cmd: ['addredeem'],
  desc: 'Buat redeem code',
  owner: true,
  
  async run(bot, ctx, db) {
    const q = ctx.message.reply_to_message
    const args = ctx.message.text.split(' ')
    
    // 1. Detect Media
    let media = null
    let type = null
    let fileIdOrUrl = null

    if (q) {
      if (q.photo) {
        fileIdOrUrl = q.photo[q.photo.length - 1].file_id
        type = 'image'
      } else if (q.document) {
        fileIdOrUrl = q.document.file_id
        type = 'document'
      } else if (q.video) {
        fileIdOrUrl = q.video.file_id
        type = 'video'
      }
    }

    if (args.length < 2) {
      await ctx.reply(`
╭━━━━━━━━━━━━━━━━━━╮
│  🎁 *ADD REDEEM*
╰━━━━━━━━━━━━━━━━━━╯

Cara pakai:
Reply Image/File (Opsional) lalu ketik:
\`/addredeem <saldo> [code] [expired]\`

Contoh:
\`/addredeem 50000\` - Auto generate code
\`/addredeem 50000 PROMO123\` - Custom code
\`/addredeem 50000 PROMO123 1d\` - Expired 1 hari

Expired format:
• 1h = 1 jam
• 1d = 1 hari  
• 7d = 7 hari
• Kosongkan untuk unlimited

💡 Code akan auto generate jika tidak diisi
`.trim(), { parse_mode: 'Markdown' })
      return
    }

    // SMART ARGUMENT PARSING 🧠
    let saldo = 0
    let code = ''
    let expiredInput = null
    
    // Cek argumen pertama (apakah angka atau teks?)
    const firstArg = args[1]
    
    if (/^\d+$/.test(firstArg)) {
        // CASE A: Angka -> Input Saldo (Normal)
        // Format: /addredeem <saldo> [code] [expired]
        saldo = parseInt(firstArg)
        code = args[2] ? args[2].toUpperCase() : generateRedeemCode()
        expiredInput = args[3] || null
    } else {
        // CASE B: Teks -> Input Code (Saldo 0 / Bonus File Only)
        // Format: /addredeem <code_name> [expired]
        saldo = 0
        code = firstArg.toUpperCase()
        expiredInput = args[2] || null
    }

    // Validasi Logika
    // Redeem tidak berguna jika Saldo 0 DAN Tidak ada file
    //!fileIdOrUrl check is needed but media logic is below. Check `q` or `fileIdOrUrl` which was set above.
    // Wait, fileIdOrUrl logic is above.
    
    if (saldo === 0 && !fileIdOrUrl) {
      await ctx.reply('❌ Jika saldo 0, wajib lampirkan File/Media sebagai hadiahnya!')
      return
    }

    // Lanjut ke Media Logic...

    // 2. Process Media Download
    if (fileIdOrUrl) {
       try {
          const axios = (await import('axios')).default
          const fs = (await import('fs')).default
          const path = (await import('path')).default

          console.log(`[TRACE REDEEM] ⬇️ Downloading media for code ${code}...`)
          
          let fileLink = await ctx.telegram.getFileLink(fileIdOrUrl)
          let ext = 'jpg'
          const filePath = fileLink.pathname 
          const pathExt = path.extname(filePath)
          if (pathExt) ext = pathExt.replace('.', '')

          // Setup Local Path
          const redeemDir = path.resolve('database/redeem')
          if (!fs.existsSync(redeemDir)) fs.mkdirSync(redeemDir, { recursive: true })
          
          const fileName = `${code}.${ext}`
          const localFilePath = path.join(redeemDir, fileName)

          // Download
          const response = await axios({
              url: fileLink.href, 
              method: 'GET',
              responseType: 'stream'
          })

          const writer = fs.createWriteStream(localFilePath)
          response.data.pipe(writer)

          await new Promise((resolve, reject) => {
              writer.on('finish', resolve)
              writer.on('error', reject)
          })

          media = {
              type,
              url: fileIdOrUrl,
              localPath: localFilePath
          }
          console.log(`[TRACE REDEEM] ✅ Media saved: ${localFilePath}`)

       } catch (err) {
           console.error(`[TRACE REDEEM] ❌ Download failed:`, err)
           await ctx.reply('⚠️ Gagal download media, code dibuat tanpa file.')
       }
    }

    try {
      // Pass media to DB
      const redeemData = await db.createRedeemCode(code, saldo, expiredInput, media)
      
      let msg = `
✅ *REDEEM CODE BERHASIL DIBUAT!*

� Code: \`${code}\`
💰 Saldo: ${formatRupiah(saldo)}
⏰ Expired: ${formatExpiry(redeemData.expired)}
`
      if (media) msg += `� File: Attached (${type})\n`
      
      msg += `\n━━━━━━━━━━━━━━━━━━\nBagikan code ini ke user!`

      await ctx.reply(msg.trim(), { parse_mode: 'Markdown' })
    } catch (error) {
      await ctx.reply(`❌ ${error.message}`)
    }
  }
}
