export default {
  cmd: ['broadcast', 'bc'],
  desc: 'Kirim pesan ke semua user',
  owner: true,
  
  async run(bot, ctx, db) {
    const args = ctx.message.text.split(' ')
    const users = Object.keys(db.data.users || {})
    
    // Cek reply message (untuk broadcast gambar/file)
    const replyMsg = ctx.message.reply_to_message
    
    // Jika tidak ada reply dan tidak ada teks argumen
    if (!replyMsg && args.length < 2) {
      await ctx.reply('❌ Masukkan pesan atau reply gambar/file untuk dibroadcast!', { parse_mode: 'Markdown' })
      return
    }

    const messageText = args.slice(1).join(' ') || (replyMsg ? (replyMsg.caption || replyMsg.text || '') : '')
    
    // Konfirmasi
    await ctx.reply(`⚠️ *Memulai Broadcast...*
👥 Target: ${users.length} User
⏳ Estimasi: ${Math.ceil(users.length * 1.5)} detik

_Mohon tunggu, laporan akan dikirim setelah selesai._`, { parse_mode: 'Markdown' })

    let success = 0
    let failed = 0
    
    // Loop send safe
    for (const userId of users) {
        try {
            // Delay 1.5 detik per user (Anti Flood)
            await new Promise(r => setTimeout(r, 1500))
            
            if (replyMsg) {
                // Copy message (aman untuk semua tipe media)
                await ctx.telegram.copyMessage(userId, ctx.chat.id, replyMsg.message_id, {
                    caption: messageText, // Override caption if provided
                    parse_mode: 'Markdown'
                })
            } else {
                // Send Text Only
                await ctx.telegram.sendMessage(userId, `${messageText}`, { parse_mode: 'Markdown' })
            }
            
            success++
        } catch (err) {
            console.error(`Gagal BC ke ${userId}:`, err.message)
            failed++
        }
    }
    
    // Report
    await ctx.reply(`✅ *BROADCAST SELESAI*
    
📨 Terkirim: ${success}
❌ Gagal: ${failed}
👥 Total: ${users.length}`, { parse_mode: 'Markdown' })
  }
}
