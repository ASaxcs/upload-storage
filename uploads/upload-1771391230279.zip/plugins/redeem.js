import { formatRupiah } from '../lib/helpers.js'

export default {
  cmd: ['redeem'],
  desc: 'Redeem code untuk dapat saldo',
  owner: false,
  
  async run(bot, ctx, db) {
    const args = ctx.message.text.split(' ')
    
    if (args.length < 2) {
      await ctx.reply(`
╭━━━━━━━━━━━━━━━━━━╮
│  🎁 *REDEEM CODE*
╰━━━━━━━━━━━━━━━━━━╯

Cara pakai:
\`/redeem <CODE>\`

Contoh:
\`/redeem ABC12345\`

💡 Dapatkan code dari owner!
      `.trim(), { parse_mode: 'Markdown' })
      return
    }

    const code = args[1].toUpperCase()

    try {
      const redeemData = await db.useRedeemCode(code, ctx.from.id)
      const { saldo, media } = redeemData
      
      let msg = `
✅ *REDEEM BERHASIL!*

🎁 Code: \`${code}\`
💰 Saldo didapat: ${formatRupiah(saldo)}

━━━━━━━━━━━━━━━━━━
Cek saldo: /mysaldo`

      // 1. Send Success Text
      await global.sendMessage(ctx, msg.trim(), { parse_mode: 'Markdown' })
      
      // 2. Send File if attached
      if (media) {
         try {
             // Prioritize Local Path
             const source = media.localPath ? { source: media.localPath } : media.url
             const caption = `_Bonus File Redeem: ${code}_`
             
             // Send as Document (File)
             await global.sendFile(ctx, source, caption)
         } catch (err) {
             console.error('Failed to send redeem media:', err)
             await ctx.reply('⚠️ Gagal mengirim file bonus.')
         }
      }
      
    } catch (error) {
      await ctx.reply(`❌ ${error.message}`)
    }
  }
}
