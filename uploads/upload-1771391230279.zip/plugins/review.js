import { Markup } from 'telegraf'

export default {
  cmd: ['review', 'ulasan'],
  desc: 'Lihat ulasan user',
  owner: false,
  
  async run(bot, ctx, db) {
      // 1. Ambil List Reviews
      // Jika ada teks setelah command, berarti user mau nulis review (Shortcut)
      // /review Mantap bang!
      
      const args = ctx.message.text.split(' ')
      
      // Smart Argument Parsing (Rating 1-5?)
      let rating = 5
      let inputReview = ''
      
      const firstArg = args[1]
      const isNumber = /^[1-5]$/.test(firstArg) // 1-5 only
      
      if (isNumber) {
          rating = parseInt(firstArg)
          inputReview = args.slice(2).join(' ')
      } else {
          rating = 5 // Default
          inputReview = args.slice(1).join(' ')
      }
      
      if (inputReview) {
          // Add Review
          await db.addReview(ctx.from.username || 'User', inputReview, rating)
          
          await ctx.reply(`✅ *Terima kasih!* Ulasanmu telah disimpan.\nRating: ${'⭐'.repeat(rating)}`, { parse_mode: 'Markdown' })
          
          // Notify Owner Group
          if (global.ownerGroupId) {
              try {
                  const notif = `⭐ *ULASAN BARU*\n\n👤 Dari: @${ctx.from.username || 'User'} (${ctx.from.id})\n⭐ Rating: ${rating}/5\n💬 Pesan: "${inputReview}"`
                  await bot.telegram.sendMessage(global.ownerGroupId, notif, { parse_mode: 'Markdown' })
              } catch (err) {
                  console.error('Gagal lapor ulasan ke owner:', err.message)
              }
          }
          return
      }

      // Show Reviews
      const reviews = db.getReviews(5) // Ambil 5 terbaru
      
      let msg = `*⭐ ULASAN PELANGGAN*\n\n`
      
      if (reviews.length === 0) {
          msg += `_Belum ada ulasan._`
      } else {
          reviews.forEach(r => {
              const date = new Date(r.date).toLocaleDateString('id-ID')
              msg += `👤 *${r.username}* (${date})\n`
              msg += `💬 "${r.text}"\n`
              msg += `⭐ ${'★'.repeat(r.rating)}\n\n`
          })
      }
      
      msg += `\n_Ketik "/review [1-5] <teks>" untuk ulasan._`

      const keyboard = Markup.inlineKeyboard([
          [Markup.button.callback('🔙 Kembali ke Menu', 'refresh_info')]
      ])

      await global.sendButton(ctx, msg, {
          parse_mode: 'Markdown',
          ...keyboard
      })
  }
}
